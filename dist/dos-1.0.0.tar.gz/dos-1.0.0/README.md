# dos

2 for one!

Validate and Document your Flask App with the same chunk of code

Developed at [Capital Rx](https://cap-rx.com/), open sourced with permission from [Ryan Kelley, CTO](https://github.com/f0rk). 